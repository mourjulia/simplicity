# Projeto Simplicity

Pequeno site de 4 páginas criado para estudos das linguagens **HTML**, **CSS** e **JavaScript**.